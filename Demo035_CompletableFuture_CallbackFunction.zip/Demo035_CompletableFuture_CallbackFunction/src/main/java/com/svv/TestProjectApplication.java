package com.svv;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestProjectApplication {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		SpringApplication.run(TestProjectApplication.class, args);
		
		ExecutorService exeService = Executors.newFixedThreadPool(3);
		
		
		 CompletableFuture.supplyAsync(
				
				()->{
					A a = new A();
					return a.test();
				}
				
				,exeService).thenApplyAsync((resultA)->
		         
		        {B b = new B();
		        return resultA+" "+b.test();
		        
		        
		        }
		        ,exeService).thenApplyAsync((resultB) -> 
		        
		        {
		        	C c = new C();
		        	return resultB+" "+c.test();
		        }		
		        
		        ,exeService).thenAccept(value -> System.out.println(value));
		
		
		System.out.println("line executed "+ Thread.currentThread().getName());
		
	}

}
